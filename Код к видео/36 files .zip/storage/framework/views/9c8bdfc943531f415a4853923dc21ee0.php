<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .email-container {
            max-width: 1000px;
            margin: 20px auto;
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .header {
            background-color: #007bff;
            color: #ffffff;
            padding: 20px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }
        .content {
            padding: 20px;
        }
        .order-details {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .order-details th, .order-details td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        .order-details th {
            background-color: #f8f9fa;
        }
        .footer {
            text-align: center;
            padding: 10px;
            font-size: 12px;
            color: #888;
        }
    </style>
</head>
<body style="font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f4;">
<div class="email-container" style="max-width: 1000px; margin: 20px auto; background-color: #ffffff; border: 1px solid #ddd; border-radius: 5px;">
    <div class="header" style="background-color: #007bff; color: #ffffff; padding: 20px; text-align: center; font-size: 24px; font-weight: bold;">Заказ #<?php echo e($order_id); ?> на сайте <?php echo e(config('app.name')); ?></div>
    <div class="content" style="padding: 20px;">

        На сайте был сделал новый заказ...

    </div>
    <div class="footer" style="text-align: center; padding: 10px; font-size: 12px; color: #888;">
        Это письмо создано автоматически. Пожалуйста, не отвечайте на него.
    </div>
</div>
</body>
</html>

<?php /**PATH D:\Server6\OSPanel\home\laravel-eshop.loc\resources\views/mail/order-manager.blade.php ENDPATH**/ ?>