<div>
    <h1>Product page</h1>
</div>
<?php /**PATH D:\Server6\OSPanel\home\laravel-eshop.loc\resources\views/livewire/product/product-component.blade.php ENDPATH**/ ?>