<div>
    <h1>Category page</h1>
</div>
<?php /**PATH D:\Server6\OSPanel\home\laravel-eshop.loc\resources\views/livewire/product/category-component.blade.php ENDPATH**/ ?>